﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MVC_CollegeManagement.Models;
using Microsoft.AspNetCore.Authorization;

namespace MVC_CollegeManagement.Controllers
{
    [Authorize]
    public class ProfessorsController : Controller
    {
        private readonly ApplicationContext _context;

        public ProfessorsController(ApplicationContext context)
        {
            _context = context;
        }

        /*// GET: Professors
        public async Task<IActionResult> Index()
        {
            return View(await _context.Professor.ToListAsync());
        }*/


        public async Task<IActionResult> Index(string name)
        {
            var professors = await _context.Professor.ToListAsync();
            
            if (!String.IsNullOrEmpty(name))
            {
                string pr_name = name.ToLower();
                professors = professors.Where(s => s!.LastName.ToLower().Contains(pr_name)).ToList();
                ViewBag.isSearch = true;
            }

            if (professors == null)
            {
                return NotFound();
            }
            return View(professors);
        }

        [Authorize(Roles = "professor")]
        public async Task<IActionResult> Students(string searchStr)
        {
            var students = await _context.Student.ToListAsync();
            if (!String.IsNullOrEmpty(searchStr))
            {
                string st_name = searchStr.ToLower();
                students = students.Where(s => s!.FirstName.ToLower().Contains(st_name)).ToList();
                ViewBag.isSearch = true;
            }
            
            if(students == null)
            {
                return NotFound();
            }
            return View(students);
        }

        [Authorize(Roles = "professor")]
        public IActionResult Courses(string sEmail)
        {
            var courses = _context.StudentCourse.Where(c => c.Email == sEmail).ToList();
            return View(courses);
        }

        [Authorize(Roles = "professor")]
        public async Task<IActionResult> Grade(int cId, string sEmail)
        {
            var grade = await _context.Grade.FirstOrDefaultAsync(a => a.CourseId == cId && a.Email == sEmail);
            ViewBag.cId = cId;
            ViewBag.sEmail = sEmail;
            ViewBag.grade = grade;
            return View();
        }

        [Authorize(Roles = "professor")]
        public async Task<RedirectToActionResult> UpdateGrade([Bind("GradeId, Mark, CourseId, Email")] Grade grade)
        {
            _context.Update(grade);
            await _context.SaveChangesAsync();
            return RedirectToAction("Students", "Professors");
        }

        [Authorize(Roles = "professor")]
        public async Task<RedirectToActionResult> AddGrade([Bind("GradeId, Mark, CourseId, Email")] Grade grade)
        {
            _context.Add(grade);
            await _context.SaveChangesAsync();
            return RedirectToAction("Students", "Professors");
        }

        [Authorize(Roles = "professor")]
        public async Task<IActionResult> Profile(string email)
        {
            var profile = await _context.Professor.FirstOrDefaultAsync(p => p.Email == email);
            if (profile == null)
            {
                return NotFound();
            }
            return View(profile);
        }

        public IActionResult Home()
        {
            return View();
        }

        // GET: Professors/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var professor = await _context.Professor
                .FirstOrDefaultAsync(m => m.Id == id);
            if (professor == null)
            {
                return NotFound();
            }

            return View(professor);
        }

        [Authorize(Roles ="admin")]
        // GET: Professors/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Professors/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "admin")]
        public async Task<IActionResult> Create([Bind("Id,FirstName,LastName,Email,PnoneNumber")] Professor professor)
        {
            if (ModelState.IsValid)
            {
                _context.Add(professor);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(professor);
        }

        // GET: Professors/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var professor = await _context.Professor.FindAsync(id);
            if (professor == null)
            {
                return NotFound();
            }
            return View(professor);
        }

        // POST: Professors/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("Id,FirstName,LastName,Email,PnoneNumber")] Professor professor)
        {
            if (id != professor.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(professor);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProfessorExists(professor.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(professor);
        }

        // GET: Professors/Delete/5
        [Authorize(Roles = "admin")]
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var professor = await _context.Professor
                .FirstOrDefaultAsync(m => m.Id == id);
            if (professor == null)
            {
                return NotFound();
            }

            return View(professor);
        }

        // POST: Professors/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "admin")]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var professor = await _context.Professor.FindAsync(id);
            _context.Professor.Remove(professor);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProfessorExists(string id)
        {
            return _context.Professor.Any(e => e.Id == id);
        }
    }
}
