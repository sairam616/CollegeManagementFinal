﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using MVC_CollegeManagement.Models;

namespace MVC_CollegeManagement.Models
{
    /*Since we use Identity, the data context class will be inherited
     not from DbContext, but from IdentityDbContext*/
    public class ApplicationContext : IdentityDbContext<User>
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options)
            : base(options)
        {
            Database.EnsureCreated();
        }
        public DbSet<Professor> Professor { get; set; }
        public DbSet<Student> Student { get; set; }
        public DbSet<Course> Course { get; set; }

        public DbSet<Grade> Grade { get; set; }
        public DbSet<StudentCourse> StudentCourse { get; set; }
        public DbSet<MVC_CollegeManagement.Models.Feedback> Feedback { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Student>().HasData(
                new Student
                {
                    StudentId = "N01420662",
                    FirstName = "Sangeetha",
                    LastName = "Aman",
                    Email = "san@gmail.com",
                    PhoneNumber = "987765543357"
                },
                new Student
                {
                    StudentId = "N014211334",
                    FirstName = "Sairam",
                    LastName = "Sairam",
                    Email = "sairam@gmail.com",
                    PhoneNumber = "48776584337"
                },
                new Student
                {
                    StudentId = "N01454647",
                    FirstName = "Nurlybek",
                    LastName = "Nurlybek",
                    Email = "nurlybek@gmail.com",
                    PhoneNumber = "783646462837"
                },
                new Student
                {
                    StudentId = "N014d5464",
                    FirstName = "User2",
                    LastName = "User2",
                    Email = "user2@gmail.com",
                    PhoneNumber = "783646462837"
                }
            );

            modelBuilder.Entity<StudentCourse>().HasData(
                new StudentCourse
                {
                    CourseId = 1,
                    CourseCode = "ITS5432",
                    Name="DotNet",
                    Email = "user2@gmail.com"
                },
                new StudentCourse
                {
                    CourseId = 2,
                    CourseCode = "ITS5433",
                    Name = "J2EE",
                    Email = "user2@gmail.com"
                },
                new StudentCourse
                {
                    CourseId = 3,
                    CourseCode = "ITS5432",
                    Name = "DotNet",
                    Email = "sairam@gmail.com"
                },
                new StudentCourse
                {
                    CourseId = 4,
                    CourseCode = "ITS5433",
                    Name = "J2EE",
                    Email = "nurlybek@gmail.com"
                }
            );

            modelBuilder.Entity<Professor>().HasData(
                new Professor
                {
                    Id= "1",
                    FirstName = "Nithya",
                    LastName = "Nithya",
                    Email = "nithya@gmail.com",
                    PhoneNumber ="7886487364"
                },
                new Professor
                {
                    Id = "2",
                    FirstName = "User2",
                    LastName = "Nithya2",
                    Email = "user2@gmail.com",
                    PhoneNumber = "387467834"
                }
            );
        }
    }
}
