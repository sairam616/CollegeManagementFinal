﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MVC_CollegeManagement.Models
{
    public class Grade
    {
        [Required]
        [Key]
        public int GradeId { get; set; }
        [Required]
        public int Mark { get; set; }
        [Required]
        public int CourseId { get; set; }
        [Required]
        public string Email { get; set; }
    }
}
